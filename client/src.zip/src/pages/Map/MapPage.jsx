import { useMemo, useState } from "react";
import Map from "../../components/Map/Map";
import Sidebar from "../../components/Sidebar/Sidebar";
import useEvents from "../../hooks/useEvents";
import "./MapPage.css";

export default function MapPage() {
  const { events, loading, error } = useEvents();

  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  const filteredEvents = useMemo(() => {
    return events.filter((event) => {
      const eventDate = new Date(event.date);

      if (dateFrom && eventDate < new Date(dateFrom)) return false;
      if (dateTo && eventDate > new Date(dateTo)) return false;

      return true;
    });
  }, [events, dateFrom, dateTo]);

  return (
    <div className="map-page-root">
      <Sidebar
        dateFrom={dateFrom}
        dateTo={dateTo}
        setDateFrom={setDateFrom}
        setDateTo={setDateTo}
        events={filteredEvents}
        loading={loading}
        error={error}
      />

      <Map events={filteredEvents} />
    </div>
  );
}
